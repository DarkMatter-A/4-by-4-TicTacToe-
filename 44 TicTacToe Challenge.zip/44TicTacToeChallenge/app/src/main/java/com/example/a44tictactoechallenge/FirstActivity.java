package com.example.a44tictactoechallenge;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class FirstActivity extends AppCompatActivity {

    boolean playBot;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        intent = new Intent(this, MainActivity.class);
    }

    public void setBotTrue(View view){
        playBot = true;
        changeToMainActivity();
    }

    public void setBotFalse(View view){
        playBot = false;
        changeToMainActivity();
    }

    private void changeToMainActivity(){
        intent.putExtra("playBot", playBot);
        startActivity(intent);
    }
}