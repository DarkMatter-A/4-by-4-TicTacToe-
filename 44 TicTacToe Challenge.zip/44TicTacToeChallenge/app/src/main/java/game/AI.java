package game;

import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.Arrays;

public class AI extends GameLogic{



    public AI(){}

    public AI(View announce, View replay, View linearLayout, View turnview, Animation fadein, Animation fadeout) {
        super(announce, replay, linearLayout, turnview, fadein, fadeout);
    }


    public int[] findMove(){
        int[] move = new int[2];
        int maxScore = 0;
        for(int i=0; i<4; i++){
            for(int j=0; j<4; j++){
                if(grid[i][j]==0) {
                    Log.i("Score","At co-ordinate "+String.valueOf(i)+" "+String.valueOf(j));
                    int[][][] WinningRows = findWinningRows(i, j);
                    Log.i("Score","Rows to check are "+ Arrays.deepToString(WinningRows));
                    int ScoreOfCordinate = calculateScore(WinningRows);
                    if(ScoreOfCordinate>=maxScore){
                        maxScore = ScoreOfCordinate;
                        move[0]=i;
                        move[1]=j;
                    }
                }
            }
        }
        return move;
    }

    private int calculateScore(int[][][] WinningRows){
        int score = 0;
        for(int i=0; i<3; i++){//For loop to traverse 3 possible winning rows
            if(WinningRows[i]!=null) {
                Log.i("Score","For Row "+i);
                int sum = 0;// To store the sum of value of co-ordinates in the given rows
                int no_of_zeros = 0;// To store the number of empty co-ordinates in given row
                for (int j = 0; j < 4; j++) {//loop to traverse 4 co-ordinates
                    int value = grid[WinningRows[i][j][0]][WinningRows[i][j][1]];
                    if (value == 0) {
                        no_of_zeros++;//calculating total number of zeros in given row
                    }
                    sum = sum + value;//Calculating total value of given row
                }
                Log.i("Score","No of Zeros: "+no_of_zeros);
                Log.i("Score","Sum: "+sum);
                if (isWinnable(no_of_zeros, sum)) {
                    score = score + 2;
                    Log.i("Score","+2 for being winnable");
                }
                if (isBlocking(no_of_zeros, sum)) {
                    score = score + 1;
                    Log.i("Score","+1 for being blockable");
                }
                if (isPreventingLoss(no_of_zeros, sum)) {
                    score = score + 6;
                    Log.i("Score","+6 for preventing loss");
                }
                if (isWinning(no_of_zeros, sum)) {
                    score = score + 7;
                    Log.i("Score","+7 for winning");
                }
            }
            Log.i("Score","Total Score: "+score);
        }
        return score;
    }

    private boolean isWinnable(int no_of_zeros, int sum){//if a certain row is winnable by blue
        if((no_of_zeros == 1 && (sum==3)) || (no_of_zeros == 2 && (sum==2)) || (no_of_zeros == 3 && (sum==1)) || no_of_zeros==4){
            return true;
        }
        else{
            return false;
        }
    }

    private boolean isBlocking(int no_of_zeros, int sum){// If playing here blocks red from winning
        if((no_of_zeros==1 && (sum==-3)) || (no_of_zeros==2 && (sum==-2)) || (no_of_zeros==3 && (sum==-1))){
            return true;
        }
        else {
            return false;
        }
    }

    private boolean isPreventingLoss(int no_of_zeros, int sum){//If playing here prevents blue from loosing
        if(no_of_zeros==1 && sum==-3){
            return true;
        }
        else {
            return false;
        }
    }

    private boolean isWinning(int no_of_zeros, int sum){//If playing here causes blue to win
        if(no_of_zeros==1 && sum==3){
            return true;
        }
        else {
            return false;
        }
    }

    private int[][][] findWinningRows(int i, int j){
        int[][][] returnArray = new int[3][4][2];
        //functuion to return horizontal winning row
        returnArray[0] = horrizontalRow(i,j);
        //functuion to return vertical winning row
        returnArray[1] = verticalRow(i,j);
        //function to return diagonal rows
        returnArray[2] = diagonalRow(i,j);
        return returnArray;
    }


    private int[][] horrizontalRow(int i, int j){
        int[][] row = new int[4][2];//co-ordinates of horrizontal winning row to return
        for (int k = 0; k<4; k++){
            for(int l=0; l<2; l++){
                if(l==0){
                    row[k][l] = i;// horizontal(x) index of winning row
                }
                if(l==1){
                    row[k][l] = k;// vertical(y) index of winning row
                }
            }
        }
        return  row;
    }

    private int[][] verticalRow(int i, int j){
        int[][] row = new int[4][2];//co-ordinates of vertical winning row to return
        for (int k = 0; k<4; k++) {
            for (int l = 0; l < 2; l++) {
                if (l == 0) {
                    row[k][l] = k;// horizontal(x) index of winning row
                }
                if (l == 1) {
                    row[k][l] = j;// vertical(y) index of winning row
                }
            }
        }
        return  row;
    }

    private int[][] diagonalRow(int i, int j){
        int[][] row = new int[4][2];//co-ordinates of row diagonal of (i,j) which will be considered to win

        if(i==j){                   //if (i,j) is element of diagonal 1 going from top left to bottom right return diagonal 1
            for (int k = 0; k<4; k++) {
                for (int l = 0; l < 2; l++) {
                    if (l == 0) {
                        row[k][l] = k;// horizontal(x) index of winning row
                    }
                    if (l == 1) {
                        row[k][l] = k;// vertical(y) index of winning row
                    }
                }
            }
            return row;
        }
        if(i+j==3){             //if (i,j) is element of diagonal 2 going from top right to bottom left return diagonal 2
            for (int k = 0; k<4; k++) {
                for (int l = 0; l < 2; l++) {
                    if (l == 0) {
                        row[k][l] = 3-k;// horizontal(x) index of winning row
                    }
                    if (l == 1) {
                        row[k][l] = k;// vertical(y) index of winning row
                    }
                }
            }
            return row;
        }
        else return null;
    }

    public void play(){
        if(turn.equals("Blue's Turn")) {
            int[] move = findMove();
            LinearLayout column = (LinearLayout) linearLayout.getChildAt(move[1]);//get column
            ImageView image = (ImageView) column.getChildAt(move[0]); // get image of coressponding row
            setposition(image, move[0], move[1]);
            fadein.setDuration(500);
            image.startAnimation(fadein);
            Log.i("anim", "AI animation started");
        }
    }
}
