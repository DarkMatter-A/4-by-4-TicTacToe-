package com.example.a44tictactoechallenge;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.TransitionManager;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import game.AI;
import game.GameLogic;

public class MainActivity extends AppCompatActivity {

    TextView announce;
    Button replay;
    LinearLayout linearLayout;
    TextView turnview;
    AI game;
    Animation fadein;
    Animation fadeout;
    Boolean playBot = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
        setContentView(R.layout.activity_main);

        if(getIntent().getExtras()!=null){playBot = (Boolean) getIntent().getExtras().get("playBot");}
        announce = findViewById(R.id.announce);
        replay = findViewById(R.id.replay);
        linearLayout = findViewById(R.id.linearLayout);
        turnview = findViewById(R.id.Turn);
        fadein = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fadein);
        fadeout = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.fadeout);
        game = new AI(announce, replay, linearLayout, turnview, fadein, fadeout);
    }


    public void touch(View view) {
        int row;
        int column;
        row = ((LinearLayout)view.getParent()).indexOfChild(view);
        column = ((LinearLayout)((LinearLayout)view.getParent()).getParent()).indexOfChild((LinearLayout)view.getParent());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            getContentTransitionManager();
            TransitionManager.endTransitions(findViewById(R.id.container));
        }
        game.setposition(view,row,column);
        if(playBot) {
            game.play();
        }
    }

    public void Reset(View view) {
        game.reset();
        ImageView imageView;
        imageView = findViewById(R.id.i1);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i2);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i3);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i4);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i5);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i6);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i7);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i8);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i9);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i10);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i11);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i12);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i13);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i14);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i15);
        imageView.setImageResource(R.drawable.empty);
        imageView = findViewById(R.id.i16);
        imageView.setImageResource(R.drawable.empty);
    }
}