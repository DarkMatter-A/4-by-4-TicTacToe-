package game;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.Arrays;

import com.example.a44tictactoechallenge.R;

public class GameLogic {
    TextView announce;
    Button replay;
    LinearLayout linearLayout;
    TextView turnView;
    Animation fadein;
    Animation fadeout;

    public GameLogic(){}

    public GameLogic(View announce, View replay, View linearLayout, View turnview, Animation fadein, Animation fadeout) {
        this.announce = (TextView) announce;
        this.replay = (Button) replay;
        this.linearLayout = (LinearLayout) linearLayout;
        this.turnView = (TextView) turnview;
        this.fadein = fadein;
        this.fadeout = fadeout;
    }

    protected String turn = "Red's Turn";
    protected int[][] grid ={{0,0,0,0},
                             {0,0,0,0},
                             {0,0,0,0},
                             {0,0,0,0}};
    //grid represents game state as follows
    //0 for empty -1 for cross +1 for circle
    private int[] position = new int[2];
    ImageView image;

    public void setposition(View view, int i, int j){
        position[0] = i;
        position[1] = j;
        image = (ImageView)view;
        updategrid();
    }

    public void updategrid(){
        if(turn=="Red's Turn" && grid[position[0]][position[1]]==0){
            grid[position[0]][position[1]] = -1;
            image.setImageResource(R.drawable.cross);
            checkgrid();
            setturn(1);
            return;
        }
        if(turn=="Blue's Turn" && grid[position[0]][position[1]]==0){
            grid[position[0]][position[1]] = +1;
            image.setImageResource(R.drawable.circle);
            checkgrid();
            setturn(-1);
            return;
        }
        return;
    }


    public void checkgrid(){
        int sum =0;
        int no_of_zeros;
        boolean winnable = false;
        for(int i = 0; i<4; i++){
            sum = 0;
            no_of_zeros = 0;
            for(int j = 0; j<4; j++){
                sum = sum + grid[i][j];
                if(grid[i][j]==0){
                    no_of_zeros++;
                }
            }
            if(sum==4){
                blueWon();
                return;
            }
            if(sum==(-4)){
                redWon();
                return;
            }
            if((no_of_zeros == 1 && (sum==3 || sum == -3)) || (no_of_zeros == 2 && (sum==2 || sum == -2)) || (no_of_zeros == 3 && (sum==1 || sum == -1))){
                winnable = true;
            }
        }//checking rows
        for(int i = 0; i<4; i++){
            sum = 0;
            no_of_zeros = 0;
            for(int j = 0; j<4; j++){
                sum = sum + grid[j][i];
                if(grid[j][i]==0){
                    no_of_zeros++;
                }
            }
            if(sum==4){
                blueWon();
                return;
            }
            if(sum==(-4)){
                redWon();
                return;
            }
            if((no_of_zeros == 1 && (sum==3 || sum == -3)) || (no_of_zeros == 2 && (sum==2 || sum == -2)) || (no_of_zeros == 3 && (sum==1 || sum == -1))){
                winnable = true;
            }
        }//checking column
        sum = 0;
        no_of_zeros = 0;
        for(int i = 0; i<4; i++){
            sum = sum + grid[i][i];
            if(grid[i][i]==0){
                no_of_zeros++;
            }
            if(sum==4){
                blueWon();
                return;
            }
            if(sum==(-4)){
                redWon();
                return;
            }
            if((no_of_zeros == 1 && (sum==3 || sum == -3)) || (no_of_zeros == 2 && (sum==2 || sum == -2)) || (no_of_zeros == 3 && (sum==1 || sum == -1))){
                winnable = true;
            }
        }//checking diagonal 1
        sum = 0;
        no_of_zeros = 0;
        for(int i = 0; i<4; i++){
            sum = sum + grid[i][3-i];
            if(grid[i][3-i]==0){
                no_of_zeros++;
            }
            if(sum==4){
                blueWon();
                return;
            }
            if(sum==(-4)){
                redWon();
                return;
            }
            if((no_of_zeros == 1 && (sum==3 || sum == -3)) || (no_of_zeros == 2 && (sum==2 || sum == -2)) || (no_of_zeros == 3 && (sum==1 || sum == -1))){
                winnable = true;
            }
        }//checking diagonal 2

        if(!winnable){
            draw();
        }

    }

    private void redWon(){
        announce.setText("Red Won");
        fadeout.setDuration(500);
        linearLayout.startAnimation(fadeout);
        linearLayout.setVisibility(View.INVISIBLE);
        turnView.startAnimation(fadeout);
        turnView.setVisibility(View.INVISIBLE);
        fadein.setStartOffset(1500);
        announce.startAnimation(fadein);
        announce.setVisibility(View.VISIBLE);
        replay.startAnimation(fadein);
        replay.setVisibility(View.VISIBLE);
    }

    private void blueWon(){
        announce.setText("Blue Won");
        fadeout.setDuration(500);
        linearLayout.startAnimation(fadeout);
        linearLayout.setVisibility(View.INVISIBLE);
        turnView.startAnimation(fadeout);
        turnView.setVisibility(View.INVISIBLE);
        fadein.setStartOffset(1500);
        announce.startAnimation(fadein);
        announce.setVisibility(View.VISIBLE);
        replay.startAnimation(fadein);
        replay.setVisibility(View.VISIBLE);
    }

    private void draw(){
        announce.setText("Draw");
        fadeout.setDuration(500);
        linearLayout.startAnimation(fadeout);
        linearLayout.setVisibility(View.INVISIBLE);
        turnView.startAnimation(fadeout);
        turnView.setVisibility(View.INVISIBLE);
        fadein.setStartOffset(1500);
        announce.startAnimation(fadein);
        announce.setVisibility(View.VISIBLE);
        replay.startAnimation(fadein);
        replay.setVisibility(View.VISIBLE);
    }

    private void setturn(int i){
        if(i==-1){
             turn = "Red's Turn";
             turnView.setText(R.string.RedTurn);
        }
        if(i==1){
            turn = "Blue's Turn";
            turnView.setText(R.string.BlueTurn);
        }
    }
    public void reset(){
        turn = "Red's Turn";
        Arrays.fill(grid[0],0);
        Arrays.fill(grid[1],0);
        Arrays.fill(grid[2],0);
        Arrays.fill(grid[3],0);
        Arrays.fill(position,0);
        linearLayout.setVisibility(View.VISIBLE);
        turnView.setVisibility(View.VISIBLE);
        announce.setVisibility(View.INVISIBLE);
        replay.setVisibility(View.INVISIBLE);
        return;
    }

}
